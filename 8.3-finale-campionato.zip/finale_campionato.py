from pyspark import SparkContext
from campionato import analizzaPartita
sc=SparkContext()
rdd=sc.textFile('partite.txt')
partite=rdd.filter(lambda x: len(x)>0)
calcolopunti=partite.flatMap(lambda x: analizzaPartita(x))
classifica=calcolopunti.reduceByKey(lambda a,b: a+b).sortBy(lambda x: x[1], False)
classifica.saveAsTextFile('classifica')
sc.stop()
