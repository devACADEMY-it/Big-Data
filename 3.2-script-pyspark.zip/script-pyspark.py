from pyspark import SparkContext
sc=SparkContext()

print('################################')
print('################################')
print('#####    SPARK IN PYTHON   #####')
print('################################')
print('################################')

sc.stop()
