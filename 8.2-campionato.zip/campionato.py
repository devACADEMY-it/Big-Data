def analizzaPartita(partita):
  squadre,goal=partita.split()
  s1,s2=squadre.split('-')
  g1,g2=goal.split('-')
  if g1==g2:
    return [(s1,1),(s2,1)]
  elif g1>g2:
    return [(s1,3)]
  else:
    return [(s2,3)]
